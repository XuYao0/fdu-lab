package TreeAdapter

import (
	"encoding/xml"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// TreeStructureProvider 定义树形结构的核心接口，所有适配者都要实现
type TreeStructureProvider interface {
	FetchRootElement() *TreeElement
	FetchChildElements(element *TreeElement) []*TreeElement
}

// TreeElement 通用树形节点，适配所有结构的统一节点格式
type TreeElement struct {
	Label    string
	Payload  interface{}
	Branches []*TreeElement
}

// DisplayTreeStructure 通用树形打印函数（控制台版本，用制表符缩进）
// provider: 适配后的树形数据提供器
// element: 当前打印的元素节点
// indentPrefix: 缩进前缀
// isFinalChild: 是否是最后一个子节点
func DisplayTreeStructure(provider TreeStructureProvider, element *TreeElement, indentPrefix string, isFinalChild bool) {

	connector := "├── "
	if isFinalChild {
		connector = "└── "
	}

	if indentPrefix == "" {
		fmt.Println(element.Label)
	} else {
		fmt.Println(indentPrefix + connector + element.Label)
	}

	var nextIndent string
	if indentPrefix == "" {
		nextIndent = ""
	} else {
		if isFinalChild {
			nextIndent = indentPrefix + "    "
		} else {
			nextIndent = indentPrefix + "│   "
		}
	}

	// 特殊处理根节点下的第一层子节点缩进
	actualChildIndent := nextIndent
	if indentPrefix == "" {
		actualChildIndent = ""
	}

	subElements := provider.FetchChildElements(element)
	for i, subElement := range subElements {
		if indentPrefix == "" {
			DisplayTreeStructure(provider, subElement, " ", i == len(subElements)-1)
		} else {
			DisplayTreeStructure(provider, subElement, actualChildIndent, i == len(subElements)-1)
		}
	}
}

// FileSystemTreeAdapter 文件目录适配器，适配文件系统结构
type FileSystemTreeAdapter struct {
	BaseDirectory string
}

func (fsAdapter *FileSystemTreeAdapter) FetchRootElement() *TreeElement {
	// 获取绝对路径后的最后一部分作为根节点名称
	absolutePath, _ := filepath.Abs(fsAdapter.BaseDirectory)
	rootLabel := filepath.Base(absolutePath)

	return &TreeElement{
		Label:   rootLabel,
		Payload: absolutePath,
	}
}

func (fsAdapter *FileSystemTreeAdapter) FetchChildElements(element *TreeElement) []*TreeElement {
	elementPath, isValid := element.Payload.(string)
	if !isValid {
		return nil
	}

	directoryEntries, err := os.ReadDir(elementPath)
	if err != nil {
		return nil
	}

	var subElements []*TreeElement
	for _, entry := range directoryEntries {
		subElements = append(subElements, &TreeElement{
			Label:   entry.Name(),
			Payload: filepath.Join(elementPath, entry.Name()),
		})
	}
	return subElements
}

type XMLStructureNode struct {
	XMLName     xml.Name              `xml:""`
	ElementName xml.Name
	Attributes  []xml.Attr           `xml:",any,attr"`
	TextContent string               `xml:",chardata"`
	SubNodes    []XMLStructureNode   `xml:",any"`
}

// XMLStructureAdapter XML结构适配器
type XMLStructureAdapter struct {
	RootElement XMLStructureNode
}

// FetchRootElement 获取XML根节点
func (xmlAdapter *XMLStructureAdapter) FetchRootElement() *TreeElement {
	rootLabel := xmlAdapter.RootElement.XMLName.Local
	return &TreeElement{
		Label:   rootLabel,
		Payload: xmlAdapter.RootElement,
	}
}

// FetchChildElements 获取XML节点的子节点
func (xmlAdapter *XMLStructureAdapter) FetchChildElements(element *TreeElement) []*TreeElement {
	xmlNode, isValid := element.Payload.(XMLStructureNode)
	if !isValid {
		return nil
	}

	var childElements []*TreeElement
	for _, childXML := range xmlNode.SubNodes {

		if childXML.XMLName.Local == "" {
			continue
		}

		// 处理属性信息
		attributeInfo := ""
		if len(childXML.Attributes) > 0 {
			var attributeList []string
			for _, attr := range childXML.Attributes {
				attributeList = append(attributeList, fmt.Sprintf("%s=\"%s\"", attr.Name.Local, attr.Value))
			}
			attributeInfo = fmt.Sprintf(" [%s]", strings.Join(attributeList, ", "))
		}

		// 清理文本内容中的换行符和多余空格
		trimmedContent := strings.TrimSpace(childXML.TextContent)
		if trimmedContent != "" {
			trimmedContent = ": " + trimmedContent
		}

		// 构建完整的节点标签：标签名 + 属性 + 内容
		// 示例格式: book [id="myBook"]: 我的自传
		completeNodeLabel := childXML.XMLName.Local + attributeInfo + trimmedContent

		childElement := &TreeElement{
			Label:   completeNodeLabel,
			Payload: childXML,
		}
		childElements = append(childElements, childElement)
	}
	return childElements
}
